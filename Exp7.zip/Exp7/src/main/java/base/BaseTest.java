package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import utils.ConfigReader;

public class BaseTest {

    public static WebDriver driver;

    public void setup() throws Exception {

        driver = new ChromeDriver();

        driver.manage().window().maximize();

        Thread.sleep(2000);

        driver.get(ConfigReader.get("url"));

        Thread.sleep(3000);
    }

    public void close() {
        driver.quit();
    }
}