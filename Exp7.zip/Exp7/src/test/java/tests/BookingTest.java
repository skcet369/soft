package tests;

import org.testng.Assert;
import org.testng.annotations.*;

import base.BaseTest;
import pages.*;
import utils.ConfigReader;

public class BookingTest extends BaseTest {

    @BeforeMethod
    public void start() throws Exception {
        setup();
    }

    @Test
    public void bookingTest() {

        // Step 1: Search Bus
        HomePage home = new HomePage(driver);

        home.searchBus(
                ConfigReader.get("from"),
                ConfigReader.get("to"),
                ConfigReader.get("date")
        );

        // Step 2: Select Bus
        BusPage bus = new BusPage(driver);

        bus.selectBus(
                ConfigReader.get("bus")
        );

        // Step 3: Enter Passenger Details
        PassengerPage passenger = new PassengerPage(driver);

        passenger.enterDetails(
                ConfigReader.get("name"),
                ConfigReader.get("age"),
                ConfigReader.get("phone"),
                ConfigReader.get("seat")
        );

        // Step 4: Click Book/Confirm Button
        passenger.confirmBooking();

    }

    @AfterMethod
    public void end() {
    }
}