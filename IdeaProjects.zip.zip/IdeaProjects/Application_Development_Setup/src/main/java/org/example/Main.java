package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
@Component
public class Main {
    public static void main(String[] args) throws Exception {
        String url = "jdbc:postgresql://localhost:5432/Apllication_Develop_db";
        String user = "postgres";
        String pass = "Rishabh2006.";
        String sql = "select * from student";

        Connection con = DriverManager.getConnection(url,user,pass);
        Statement st = con.createStatement();
        ResultSet rs=st.executeQuery(sql);

        if (!rs.next()) {
            System.out.println("No records found.");
        } else {
            do {
                System.out.print(rs.getInt(1) + " - ");
                System.out.print(rs.getString(2) + " - ");
                System.out.println(rs.getInt(3));
            } while (rs.next());
        }

        rs.close();
        st.close();
        con.close();
    }
}
