import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class hi {
    public static void main(String[] args) throws InterruptedException{
        // Launch Browser
        WebDriver driver = new ChromeDriver();
        driver.get("https://demoqa.com/automation-practice-form");

        // finding Web Elements or Locators
        WebElement username = driver.findElement(By.id("firstName"));
        username.sendKeys("Rishabh");

        WebElement lastname = driver.findElement(By.id("lastName"));
        lastname.sendKeys("V");

        WebElement mail = driver.findElement(By.id("userEmail"));
        mail.sendKeys("hi@gmail.com");

        driver.findElement(By.xpath("//label[text()='Male']")).click();

        WebElement number = driver.findElement(By.id("userNumber"));
        number.sendKeys("7603856751");

        driver.findElement(By.xpath("//label[text()='Sports']")).click();

        WebElement location = driver.findElement(By.id("currentAddress"));
        location.sendKeys("Theni,TamilNadu");

        // upload Pic
        WebElement file = driver.findElement(By.id("uploadPicture"));
        file.sendKeys("C:\\Users\\HP\\Pictures\\Img Downloads\\vinland 2.jpg");

        driver.findElement(By.tagName("body")).sendKeys(Keys.END);
        driver.findElement(By.id("submit")).sendKeys(Keys.ENTER);

    }
}
