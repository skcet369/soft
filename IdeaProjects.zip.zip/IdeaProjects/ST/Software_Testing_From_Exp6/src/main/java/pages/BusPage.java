package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BusPage {
    WebDriver driver;
    public BusPage(WebDriver driver){
        this.driver = driver;
    }
    public void selectBus(String busName){
        driver.findElement(By.xpath("//tr[td='" + busName + "']//button")).click();
    }
}
