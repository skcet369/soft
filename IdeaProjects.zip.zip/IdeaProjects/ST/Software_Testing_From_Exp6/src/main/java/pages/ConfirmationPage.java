package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ConfirmationPage {
    WebDriver driver;

    public ConfirmationPage(WebDriver driver){
        this.driver = driver;
    }
    public  boolean bookingverify(){
        return driver.findElement(By.xpath("//h1[contains(text(), 'Booking Confirmed')]")).isDisplayed();
    }
}
