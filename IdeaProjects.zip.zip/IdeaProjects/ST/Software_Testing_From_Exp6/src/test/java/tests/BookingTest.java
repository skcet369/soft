package tests;
import base.BaseTest;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import utils.ConfigReader;
import pages.*;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class BookingTest extends BaseTest{
    @BeforeMethod
    public void start() throws Exception{
        setup();
    }
    @Test
    public void BookingTest(){
        HomePage home = new HomePage(driver);
        home.searchBus(
                ConfigReader.get("from"),
                ConfigReader.get("to"),
                ConfigReader.get("date")
        );
        BusPage bus = new BusPage(driver);
        bus.selectBus(
                ConfigReader.get("bus")
        );
        PassengerPage passenger = new PassengerPage(driver);
        passenger.passenger(
                ConfigReader.get("name"),
                ConfigReader.get("age"),
                ConfigReader.get("phone"),
                ConfigReader.get("seat")
        );
        passenger.confirmationBooking();
    }
    @AfterMethod
    public void end(){
//        close();
    }
}
