package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class HomePage {

    WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickGetQuote() throws InterruptedException {

        Thread.sleep(1000);

        driver.findElement(By.className("primary-btn")).click();

        Thread.sleep(1000);
    }

    public void scrollDown() throws InterruptedException {

        ((JavascriptExecutor) driver).executeScript(
                "window.scrollTo(0, 500);"
        );

        Thread.sleep(500);
    }
}
