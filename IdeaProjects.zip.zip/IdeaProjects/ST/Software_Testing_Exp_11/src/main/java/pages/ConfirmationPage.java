
package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ConfirmationPage {

    WebDriver driver;

    public ConfirmationPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickConfirm() throws InterruptedException {
        driver.findElement(By.id("nextBtn")).click();
        Thread.sleep(1000);
    }

    public String getSuccessMessage() {
        return driver.findElement(By.cssSelector(".success h2")).getText();
    }
}