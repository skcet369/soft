package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PatientPage {
    WebDriver driver;
    public PatientPage(WebDriver driver){
        this.driver = driver;
    }
    public void enterPatient(){
        driver.findElement(By.id("patientName")).sendKeys("Rishabh");
        driver.findElement(By.id("phone")).sendKeys("7603856751");
        driver.findElement(By.id("email")).sendKeys("rishabh.vr2006@gmail.com");
        driver.findElement(By.id("dob")).sendKeys("24-12-2006");
        driver.findElement(By.id("gender")).sendKeys("Male");
        driver.findElement(By.id("patientType")).sendKeys("New patient");
        driver.findElement(By.id("reason")).sendKeys("Heart Check-up");
    }
    public void patientNext(){
        driver.findElement(By.id("patientNext")).click();
    }
    public void confirmButton(){
        driver.findElement(By.id("confirmButton")).click();
    }
}
