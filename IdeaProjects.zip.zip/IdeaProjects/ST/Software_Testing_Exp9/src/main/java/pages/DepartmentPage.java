package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DepartmentPage {
    WebDriver driver;
    public DepartmentPage(WebDriver driver){
        this.driver = driver;
    }
    public void selectCardiology(){
        driver.findElement(By.cssSelector(".department[data-dept='Cardiology']")).click();
    }
}
