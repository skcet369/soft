package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AppointmentPage {
    WebDriver driver;
    public AppointmentPage(WebDriver driver){
        this.driver = driver;
    }
    public void selectDate(){
        driver.findElement(By.cssSelector(".date")).click();
    }
    public void selectTime(){
        driver.findElement(By.cssSelector(".time:not(.booked)")).click();
    }
    public void dateNext(){
        driver.findElement(By.id("dateNext")).click();
    }
}
