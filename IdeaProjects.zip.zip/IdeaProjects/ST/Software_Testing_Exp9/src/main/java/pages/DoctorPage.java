package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DoctorPage {
    WebDriver driver;
    public DoctorPage(WebDriver driver){
        this.driver = driver;
    }
    public void selectDoctor(){
        WebElement doctor = driver.findElement(
                By.xpath("//h4[normalize-space()='Dr. Ananya Rao']")
        );

        doctor.findElement(
                By.xpath("./ancestor::div[contains(@class,'doctor')]")
        ).click();
    }
    public void doctorNext(){
        driver.findElement(By.id("doctorNext")).click();
    }
}
