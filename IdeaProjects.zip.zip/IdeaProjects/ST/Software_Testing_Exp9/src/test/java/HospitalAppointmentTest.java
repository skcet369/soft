import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.*;

public class HospitalAppointmentTest {
    WebDriver driver;
    DepartmentPage department;
    DoctorPage doctor;
    AppointmentPage appointment;
    PatientPage patient;

    @BeforeMethod
    public void setup(){
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://mouneshgouda.github.io/Hospital-Appointment/");
        department = new DepartmentPage(driver);
        doctor = new DoctorPage(driver);
        appointment = new AppointmentPage(driver);
        patient = new PatientPage(driver);
    }
    @Test
    public void testHospital(){
        department.selectCardiology();
        doctor.selectDoctor();
        doctor.doctorNext();
        appointment.selectDate();
        appointment.selectTime();
        appointment.dateNext();
        patient.enterPatient();
        patient.patientNext();
        patient.confirmButton();
    }
}
