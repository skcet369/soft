import org.testng.annotations.Test;
import org.testng.Assert;

public class Strings {
    @Test
    public void login(){
        System.out.println("Login done");
    }
    @Test(dependsOnMethods = "login")
    public void home(){
        System.out.println("Welcome to home page");

    }
}
