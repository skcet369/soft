import org.testng.annotations.Test;
import org.testng.Assert;

public class hello {
    @Test
    public void add(){
        int a = 15+15;
        System.out.println(a);
        Assert.assertEquals(a,30);
    }
    @Test
    public void verify(){
        String actual = "google";
        String exc = "google";
        Assert.assertEquals(actual,exc);
    }
}
