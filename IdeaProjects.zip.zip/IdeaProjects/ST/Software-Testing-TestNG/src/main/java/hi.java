import org.testng.annotations.Test;

public class hi {
    @Test
    public void Login(){
        System.out.println("Welcome testing");
    }
}
