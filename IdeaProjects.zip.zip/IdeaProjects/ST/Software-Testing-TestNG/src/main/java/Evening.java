import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.Configurator;
import org.apache.logging.log4j.Level;

public class Evening {
    private static final Logger log=LogManager.getLogger(Evening.class);

    public static void main(String[] args){
        log.info("application got started");
        log.trace("application tracking starts now");
        Configurator.setRootLevel(Level.OFF);
        log.warn("this is a warning msg");
        log.error("this is a error msg");
        log.fatal("critical issues");
        log.debug("finding bug");
    }
}
