import org.testng.annotations.Test;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;


public class Afternoon {
    @Test
    public void login(){
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/");
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();

        // how can we validate crt username and password
        String currenturl = driver.getCurrentUrl();
        Assert.assertTrue(currenturl.contains("inventory"),"login failed");
        System.out.println("login success");

    }
}
