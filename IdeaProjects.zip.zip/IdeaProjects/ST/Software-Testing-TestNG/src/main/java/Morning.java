import org.testng.Assert;
import org.testng.annotations.Test;

public class Morning {
    @Test(priority = 1)
    public void add(){
        int a = 5+5;
        System.out.println(a);
        Assert.assertEquals(a,10);
    }
    @Test(priority = 0)
    public void subtract(){
        int b = 5-5;
        System.out.println(b);
        Assert.assertEquals(b,0);
    }
    @Test(priority = 2)
    public void multiply(){
        int c = 5*5;
        System.out.println(c);
        Assert.assertEquals(c,25);
    }
    @Test(priority = -1)
    public void division(){
        int d = 5/5;
        System.out.println(d);
        Assert.assertEquals(d,1);
    }
}