import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class codeTesting {

    public static void main(String[] args) throws InterruptedException {

        // 1. Initialize Browser and Maximize View
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        // 2. Open Target URL
        driver.get("https://demoqa.com/automation-practice-form");

        // 3. Fill Out Basic Text Fields
        driver.findElement(By.id("firstName")).sendKeys("Mounesh");
        driver.findElement(By.id("lastName")).sendKeys("Patil");
        driver.findElement(By.id("userEmail")).sendKeys("hi@gmail.com");

        // 4. Handle Radio Buttons & Checkboxes via Text Labels
        driver.findElement(By.xpath("//label[text()='Male']")).click();
        driver.findElement(By.id("userNumber")).sendKeys("1234567890");
        driver.findElement(By.xpath("//label[text()='Sports']")).click();

        // 5. Fill Textarea & Upload a Local File
        driver.findElement(By.id("currentAddress")).sendKeys("Bangalore, Karnataka");
        driver.findElement(By.id("uploadPicture"))
                .sendKeys("C:\\Users\\HP\\Pictures\\Amazon\\81Iv8KlTFWL._SX679_.jpg");

//        Thread.sleep(2000);

        // 6. Scroll Down to Reveal Covered Elements
        driver.findElement(By.tagName("body")).sendKeys(Keys.END);
//        Thread.sleep(1000);

        // 7. Click Submit using Keyboard Enter
        driver.findElement(By.id("submit")).sendKeys(Keys.ENTER);

        // 8. Observe Result and Close Session
//        Thread.sleep(5000);
//        driver.quit();
    }
}