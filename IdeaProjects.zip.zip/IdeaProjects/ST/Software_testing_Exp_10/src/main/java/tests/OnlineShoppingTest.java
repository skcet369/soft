package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.*;

public class OnlineShoppingTest {
    WebDriver driver;

    LoginPage loginPage;
    ProductPage productPage;
    CheckoutPage checkoutPage;
    CustomerPage customerPage;
    OverviewPage overviewPage;

    @BeforeMethod
    public void setUp(){
        driver=new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");

        loginPage=new LoginPage(driver);
        productPage=new ProductPage(driver);
        checkoutPage=new CheckoutPage(driver);
        customerPage=new CustomerPage(driver);
        overviewPage=new OverviewPage(driver);
    }

    @Test
    public void onlineShoppingTest() throws Exception {

        loginPage.LogIn();
        loginPage.loginButton();

        productPage.selectProduct();
        productPage.shoppingCart();
        checkoutPage.checkOut();
        customerPage.fillDetails();
        customerPage.continueBtn();
        overviewPage.finish();
    }

    @AfterMethod
    public void close(){
//        driver.quit();
    }
}
