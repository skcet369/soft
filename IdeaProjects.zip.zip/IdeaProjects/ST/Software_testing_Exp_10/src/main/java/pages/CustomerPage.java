package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CustomerPage {
    WebDriver driver;

    public CustomerPage(WebDriver driver){
        this.driver=driver;
    }

    public void fillDetails(){
        driver.findElement(By.id("first-name")).sendKeys("Rishabh");
        driver.findElement(By.id("last-name")).sendKeys("S");
        driver.findElement(By.id("postal-code")).sendKeys("641008");
    }

    public void continueBtn(){
        driver.findElement(By.id("continue")).click();
    }
}
