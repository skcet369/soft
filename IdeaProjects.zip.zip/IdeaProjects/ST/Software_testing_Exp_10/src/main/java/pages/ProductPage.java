package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage {
    WebDriver driver;

    public ProductPage(WebDriver driver){
        this.driver=driver;
    }

    public void selectProduct(){
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
    }

    public void shoppingCart(){
        driver.findElement(By.cssSelector("a[data-test='shopping-cart-link']")).click();
    }
}
