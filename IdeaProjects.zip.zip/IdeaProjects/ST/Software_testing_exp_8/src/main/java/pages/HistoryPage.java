package pages;

import org.openqa.selenium.WebDriver;

public class HistoryPage {

    WebDriver driver;


    public HistoryPage(WebDriver driver) {
        this.driver = driver;
    }


    public void verifyPage() {
        System.out.println("Booking Done");


    }
}

