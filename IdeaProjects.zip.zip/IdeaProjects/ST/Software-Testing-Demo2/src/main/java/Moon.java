import com.aventstack.extentreports.reporter.ExtentReporter;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class Moon {
    public static void main(String[] args) throws Exception{
        new File("6experiment").mkdir();
        ExtentReports extentReports = new ExtentReports();
        extentReports.attachReporter(new ExtentSparkReporter("6experiment/mult.html"));
        ExtentTest test = extentReports.createTest("multiple screen");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        test.pass("web page opened");
        Thread.sleep(2000);
        capture(driver,test,"01login");
        driver.findElement(By.name("username")).sendKeys("Admin");
        driver.findElement(By.name("password")).sendKeys("admin123");
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        test.pass("opened dashboard");
        Thread.sleep(2000);
        capture(driver,test,"02dashboard");
        // PIM Module
        driver.findElement(By.xpath("//span[text()='PIM']")).click();
        Thread.sleep(2000);

        test.pass("PIM View Engine Loaded");
        capture(driver, test, "03_PIM");

        // Admin Module
        driver.findElement(By.xpath("//span[text()='Admin']")).click();
        Thread.sleep(2000);

        test.pass("Admin Management Frame Loaded");
        capture(driver, test, "04_Admin");

        driver.quit();
        extentReports.flush();
        System.out.println("Automation Completed Successfully!");
        System.out.println("Report Path: reports/report.html");
    }
    public static void capture(WebDriver driver,ExtentTest test, String name) throws Exception  {
        File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        File dest = new File("reports/" + name + ".png");
        Files.copy(src.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
        test.addScreenCaptureFromPath(name + ".png");
    }
}
