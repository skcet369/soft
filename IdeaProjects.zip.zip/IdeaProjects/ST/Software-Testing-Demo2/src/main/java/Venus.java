import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class Venus {
    public static void main(String[] args){
        ExtentHtmlReporter extentHtmlReporter = new ExtentHtmlReporter("reports/report.html");
        ExtentReports extent = new ExtentReports();
        extent.attachReporter(extentHtmlReporter);
        ExtentTest test = extent.createTest("sample test case");
        test.fatal("first report generation");
        extent.flush();
    }
}
