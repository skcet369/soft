import com.aventstack.extentreports.reporter.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.openqa.selenium.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class Earth {
    public static void main(String[] args) throws Exception{
        new File("screenshot").mkdir();
        ExtentReports extentReports = new ExtentReports();
        extentReports.attachReporter(new ExtentSparkReporter("screenshot/screen.html"));
        ExtentTest test = extentReports.createTest("test case screen shot");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.google.com");
        Thread.sleep(2000);
        File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(src.toPath(),
                new File("screenshot/google.png").toPath(),
                StandardCopyOption.REPLACE_EXISTING);
        test.pass("google Attachment found").addScreenCaptureFromPath("google.png");
        driver.quit();
        extentReports.flush();
    }
}
