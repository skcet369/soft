import java.sql.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class crud {
    public static void main(String[] args) throws Exception{
        ChromeDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("C:\\Users\\HP\\IdeaProjects\\Software-Testing-Demo2\\src\\main\\java\\crud.html");
        Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/selcurd",
                "root",
                "123"
        );
        driver.findElement(By.id("name")).sendKeys("rishabh");
        driver.findElement(By.id("email")).sendKeys("rishabh.vr2006@gmal.com");
//        con.prepareStatement(
//                "insert into curd(name,email) values ('rishabh','rishabh.vr2006@gmal.com')"
//        ).executeUpdate();
        System.out.println("created");
//        driver.quit();
        driver.findElement(By.id("name")).clear();
        driver.findElement(By.id("email")).clear();

        driver.findElement(By.id("name")).sendKeys("rishabh 2.0");
        driver.findElement(By.id("email")).sendKeys("rishabh2.0@gmail.com");
//        con.prepareStatement(
//                "update curd set name='rishabh 2.0', email='rishabh2.0@gmail.com' where id=1"
//        ).executeUpdate();
        System.out.println("updated");

        con.prepareStatement("delete from curd where id=5").executeUpdate();
        System.out.println("deleted");
        driver.quit();
        Showcurd(con);
    }
    public static void Showcurd(Connection con) throws Exception{
        ResultSet rs = con.createStatement().executeQuery("select * from curd");
        while (rs.next()){
            System.out.println(rs.getInt(1)
                    +" "+rs.getString(2)
                    +" "+rs.getString(3));
        }
    }
}