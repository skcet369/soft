import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class iframe {
    public static void main(String[] args){
        WebDriver driver = new ChromeDriver();
        driver.get("https://demo.automationtesting.in/Frames.html");
        driver.manage().window().maximize();
        WebElement frame1 = driver.findElement(By.id("singleframe"));
        driver.switchTo().frame(frame1);
        driver.findElement(By.xpath("//input[@type = 'text']")).sendKeys("hello");
        driver.switchTo().defaultContent();
    }
}
