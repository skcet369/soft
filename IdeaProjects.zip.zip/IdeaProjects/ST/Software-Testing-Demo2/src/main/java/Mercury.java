import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Mercury {
    public static void main(String[] args){
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://demoqa.com/buttons");

        Actions action = new Actions(driver);
        action.doubleClick(driver.findElement(By.id("doubleClickBtn"))).perform();
        action.contextClick(driver.findElement(By.id("rightClickBtn"))).perform();
        driver.findElement(By.xpath("//button[text()='Click Me']")).click();
    }
}
