import org.testng.annotations.Test;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.Configurator;
import org.apache.logging.log4j.Level;

public class Sun {
    private static final Logger log=LogManager.getLogger(Sun.class);
    @Test
    public void game() throws InterruptedException{
        log.info("opening web page");
        WebDriver driver = new ChromeDriver();
        driver.get("https://play2048.co/");
        log.debug("Starting game interaction ...");
        Thread.sleep(2000);
            log.trace("Move up");
            driver.findElement(By.tagName("body")).sendKeys(Keys.ARROW_UP);
            Thread.sleep(2);
            log.trace("Move down");
            driver.findElement(By.tagName("body")).sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(2);
            log.trace("Move left");
            driver.findElement(By.tagName("body")).sendKeys(Keys.ARROW_LEFT);
            Thread.sleep(2);
            log.trace("Move right");
            driver.findElement(By.tagName("body")).sendKeys(Keys.ARROW_RIGHT);
            Thread.sleep(1);
            log.warn("No warnings");
            log.error("Not found any issues");
            log.fatal("Application Running Fine");
            Configurator.setRootLevel(Level.OFF);

    }
}
