import org.testng.Assert;
import org.testng.annotations.Test;

public class TestScripts_Experiment4 {

    @Test(priority = 1)
    public void testAddition() {
        int result = 10 + 20;
        Assert.assertEquals(result, 30);
        System.out.println("Addition Test Passed");
    }

    @Test(priority = 2)
    public void testSubtraction() {
        int result = 20 - 10;
        Assert.assertEquals(result, 10);
        System.out.println("Subtraction Test Passed");
    }

}