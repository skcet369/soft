import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Exp1 {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.get("https://mouneshgouda.github.io/loginpage/index.html");

        driver.manage().window().maximize();

        WebElement username = driver.findElement(By.id("softwaretesting"));
        username.sendKeys("student");

        WebElement password = driver.findElement(By.id("BatchABCDEFG"));
        password.sendKeys("Password123");

        WebElement loginButton = driver.findElement(By.id("softwaretestingsubmition"));
        loginButton.click();

        System.out.println("Page Title : " +driver.getTitle());

//        driver.quit();
    }

}