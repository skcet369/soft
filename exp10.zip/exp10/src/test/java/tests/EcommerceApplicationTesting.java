package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.LoginPage;
import pages.ProductPage;

public class EcommerceApplicationTesting {
    private WebDriver driver;
    private LoginPage loginPage;
    private ProductPage productPage;
    private CartPage cartPage;

    @BeforeMethod
    public void setUp(){
        driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();
        loginPage = new LoginPage(driver);
        productPage = new ProductPage(driver);
        cartPage = new CartPage(driver);
    }


    @Test
    public void EcommerceApplicationTesting(){
        loginPage.login("standard_user","secret_sauce");
        productPage.addProducts();
        cartPage.clickCartButton();
        cartPage.clickCheckOut();
        cartPage.fillInfo("Harish","Saravanan","614714");
        cartPage.overviewPage();
    }


   // @AfterMethod
    public void tearDown(){
        driver.quit();
    }
}
