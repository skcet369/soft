package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CartPage {
    private WebDriver driver;

    public CartPage(WebDriver driver){
        this.driver = driver;
    }

    public void clickCartButton(){
        driver.findElement(By.className("shopping_cart_link")).click();
    }
    public void clickCheckOut(){
        driver.findElement(By.id("checkout")).click();
    }
    public void fillInfo(String fname,String lname, String pinCode){
        driver.findElement(By.id("first-name")).sendKeys(fname);
        driver.findElement(By.id("last-name")).sendKeys(lname);
        driver.findElement(By.id("postal-code")).sendKeys(pinCode);
        driver.findElement(By.id("continue")).click();
    }
    public void overviewPage(){
        driver.findElement(By.id("finish")).click();
    }

}
