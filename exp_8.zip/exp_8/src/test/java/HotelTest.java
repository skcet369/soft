import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.BookingPage;
import pages.HistoryPage;
import pages.HomePage;
import pages.RoomsPage;

public class HotelTest {

    WebDriver driver;

    HomePage home;
    RoomsPage rooms;
    BookingPage booking;
    HistoryPage history;

    @BeforeMethod
    public void setup() {

        driver = new ChromeDriver();

        driver.manage().window().maximize();

        home = new HomePage(driver);
        rooms = new RoomsPage(driver);
        booking = new BookingPage(driver);
        history = new HistoryPage(driver);
    }

    @Test
    public void hotelBookingTest() throws Exception {

        home.openWebsite();

        home.searchRoom(
                "08/10/2026",
                "08/12/2026",
                "2"
        );

        Thread.sleep(2000);

        rooms.bookRoom();

        Thread.sleep(2000);

        booking.enterDetails();

        booking.confirmBooking();

        Thread.sleep(3000);

        history.verifyPage();
    }

    @AfterMethod
    public void tearDown() {

        if (driver != null) {
            driver.quit();
        }
    }
}