package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
public class PlanPage{
    WebDriver driver;
    public PlanPage(WebDriver driver){
        this.driver=driver;
    }
    public void selectPlan() throws InterruptedException{
        driver.findElement(By.cssSelector(".plan[data-plan='Standard']")).click();
        Thread.sleep(500);
    }
    public void planNext() throws InterruptedException{
        driver.findElement(By.id("nextBtn")).click();
    }

}
