package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
public class DetailsPage{
    WebDriver driver;
    public DetailsPage(WebDriver driver){
        this.driver=driver;
    }
    public void enterDetails() throws InterruptedException{
        driver.findElement(By.id("firstName")).sendKeys("hi hello");
        driver.findElement(By.id("lastName")).sendKeys("hi");
        driver.findElement(By.id("email")).sendKeys("hi@gmail.com");
        driver.findElement(By.id("age")).sendKeys("22");
        driver.findElement(By.id("location")).sendKeys("California");
        driver.findElement(By.id("extraInput")).sendKeys("SUV");
        Thread.sleep(500);
    }
    public void GoNext() throws InterruptedException{
        driver.findElement(By.id("nextBtn")).click();
        Thread.sleep(500);
    }
}