package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DoctorPage {
    private WebDriver driver;
    public DoctorPage(WebDriver driver) {
        this.driver = driver;
    }

    public  void selectDoctor(){
        driver.findElement(By.xpath(
                "//h4[normalize-space()='Dr. Ananya Rao']"
        )).click();
    }
    public void doctorNext(){
        driver.findElement(By.id("doctorNext")).click();
    }

}