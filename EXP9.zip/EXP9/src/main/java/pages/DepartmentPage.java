package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DepartmentPage {
    private WebDriver driver;
    public DepartmentPage(WebDriver driver) {
        this.driver = driver;
    }

    public void selectDepartment(){
        driver.findElement(By.cssSelector(".department[data-dept='Cardiology']")).click();
    }

}