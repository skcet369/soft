package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PatientPage {
    private WebDriver driver;

    public PatientPage(WebDriver driver) {
        this.driver = driver;
    }

    public void fillInfo(){
        driver.findElement(By.id("patientName")).sendKeys("Patient Name");
        driver.findElement(By.id("phone")).sendKeys("1234567890");
        driver.findElement(By.id("email")).sendKeys("example@gmail.com");
        driver.findElement(By.id("dob")).sendKeys("05-09-2007");
        driver.findElement(By.id("gender")).sendKeys("Male");
        driver.findElement(By.id("patientType")).sendKeys("New patient");
        driver.findElement(By.id("reason")).sendKeys("reason");
    }
    public void patientNext(){
        driver.findElement(By.id("patientNext")).click();
    }
    public void confirmButton(){
        driver.findElement(By.id("confirmButton")).click();
    }

}