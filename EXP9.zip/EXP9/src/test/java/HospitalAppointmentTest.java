package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.AppointmentPage;
import pages.DepartmentPage;
import pages.DoctorPage;
import pages.PatientPage;

public class HospitalAppointmentTest {
    private WebDriver driver;
    private AppointmentPage appointmentPage;
    private DepartmentPage departmentPage;
    private DoctorPage doctorPage;
    private PatientPage patientPage;

    public void openWebpage(){
        driver.get("https://mouneshgouda.github.io/Hospital-Appointment/");
        driver.manage().window().maximize();
    }
    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        appointmentPage = new AppointmentPage(driver);
        departmentPage = new DepartmentPage(driver);
        doctorPage = new DoctorPage(driver);
        patientPage = new PatientPage(driver);
        openWebpage();
    }


    @Test
    public void HospitalAppointmentTesting() {
        departmentPage.selectDepartment();
        doctorPage.selectDoctor();
        doctorPage.doctorNext();
        appointmentPage.selectDate();
        appointmentPage.selectTime();
        appointmentPage.dateNext();
        patientPage.fillInfo();
        patientPage.patientNext();
        patientPage.confirmButton();
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }
}