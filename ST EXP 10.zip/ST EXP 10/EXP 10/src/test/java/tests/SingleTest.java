package tests;
import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.CheckoutPage;
import pages.LoginPage;
import pages.ProductsPage;
public class SingleTest extends BaseTest {
    @Test
    public void sauceDemoCompleteTest() throws InterruptedException {
        // Step 1: Open login page
        Thread.sleep(2000);
        // Step 2: Login
        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterUsername("standard_user");
        Thread.sleep(1500);
        loginPage.enterPassword("secret_sauce");
        Thread.sleep(1500);
        loginPage.clickLogin();
        Thread.sleep(3000);
        // Step 3: Verify Products page
        ProductsPage productsPage =
                new ProductsPage(driver);
        Assert.assertEquals(
                productsPage.getPageTitle(),
                "Products"
        );
        Thread.sleep(2000);
        // Step 4: Add Backpack
        productsPage.addBackpack();
        Thread.sleep(3000);
        // Step 5: Open Cart
        productsPage.openCart();
        Thread.sleep(3000);
        // Step 6: Verify Cart
        CartPage cartPage =
                new CartPage(driver);
        Assert.assertEquals(
                cartPage.getCartItemCount(),
                1
        );
        Thread.sleep(2000);
        // Step 7: Click Checkout
        cartPage.clickCheckout();
        Thread.sleep(3000);
        // Step 8: Enter customer details
        CheckoutPage checkoutPage =
                new CheckoutPage(driver);
        checkoutPage.enterCustomerDetails(
                "Haripranav",
                "E M",
                "641008"
        );

        Thread.sleep(2000);
        // Step 9: Continue
        checkoutPage.clickContinue();
        Thread.sleep(3000);
        // Step 10: Finish purchase
        checkoutPage.clickFinish();
        Thread.sleep(3000);
        // Step 11: Verify successful order
        Assert.assertEquals(
                checkoutPage.getConfirmationMessage(),
                "Thank you for your order!"
        );
        Thread.sleep(3000);
    }
}