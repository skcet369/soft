package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
public class CheckoutPage extends BasePage {
    private final By firstName =
            By.id("first-name");
    private final By lastName =
            By.id("last-name");
    private final By postalCode =
            By.id("postal-code");
    private final By continueButton =
            By.id("continue");
    private final By finishButton =
            By.id("finish");
    private final By confirmationMessage =
            By.className("complete-header");
    public CheckoutPage(WebDriver driver) {
        super(driver);
    }
    public void enterCustomerDetails(
            String firstNameValue,
            String lastNameValue,
            String postalCodeValue) {
        wait.until(
                ExpectedConditions.visibilityOfElementLocated(firstName)
        ).sendKeys(firstNameValue);
        driver.findElement(lastName)
                .sendKeys(lastNameValue);
        driver.findElement(postalCode)
                .sendKeys(postalCodeValue);
    }
    public void clickContinue() {
        wait.until(
                ExpectedConditions.elementToBeClickable(continueButton)
        ).click();
    }
    public void clickFinish() {
        wait.until(
                ExpectedConditions.elementToBeClickable(finishButton)
        ).click();
    }
    public String getConfirmationMessage() {
        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        confirmationMessage
                )
        ).getText();
    }
}