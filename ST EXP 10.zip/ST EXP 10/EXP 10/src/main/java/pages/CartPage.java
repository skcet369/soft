package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
public class CartPage extends BasePage {
    private final By cartItems =
            By.className("cart_item");
    private final By checkout =
            By.id("checkout");
    public CartPage(WebDriver driver) {
        super(driver);
    }
    public int getCartItemCount() {
        wait.until(
                ExpectedConditions.visibilityOfElementLocated(cartItems)
        );
        return driver.findElements(cartItems).size();
    }
    public void clickCheckout() {
        wait.until(
                ExpectedConditions.elementToBeClickable(checkout)
        ).click();
    }
}