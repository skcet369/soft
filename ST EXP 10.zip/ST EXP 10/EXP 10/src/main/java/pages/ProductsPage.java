package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class ProductsPage extends BasePage {
    private final By pageTitle =
            By.cssSelector("[data-test='title']");
    private final By products =
            By.className("inventory_item");
    private final By prices =
            By.className("inventory_item_price");
    private final By sortDropdown =
            By.className("product_sort_container");
    private final By backpack =
            By.id("add-to-cart-sauce-labs-backpack");
    private final By bikeLight =
            By.id("add-to-cart-sauce-labs-bike-light");
    private final By cart =
            By.className("shopping_cart_link");
    public ProductsPage(WebDriver driver) {
        super(driver);
    }
    public String getPageTitle() {
        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(pageTitle)
        ).getText();
    }
    public int getProductCount() {
        return driver.findElements(products).size();
    }
    public void addBackpack() {
        wait.until(
                ExpectedConditions.elementToBeClickable(backpack)
        ).click();
    }
    public void addBikeLight() {
        wait.until(
                ExpectedConditions.elementToBeClickable(bikeLight)
        ).click();
    }
    public void openCart() {
        wait.until(
                ExpectedConditions.elementToBeClickable(cart)
        ).click();
    }
    public void sortLowToHigh() {
        Select select = new Select(
                wait.until(
                        ExpectedConditions.visibilityOfElementLocated(sortDropdown)
                )
        );
        select.selectByValue("lohi");
    }
    public List<Double> getPrices() {
        List<WebElement> priceElements =
                driver.findElements(prices);
        List<Double> priceList = new ArrayList<>();
        for (WebElement element : priceElements) {
            String price =
                    element.getText().replace("$", "");
            priceList.add(Double.parseDouble(price));
        }
        return priceList;
    }
}