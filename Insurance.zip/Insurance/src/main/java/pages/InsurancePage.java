package  pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
public class InsurancePage {
    WebDriver driver;
    public InsurancePage(WebDriver driver) {
        this.driver = driver;
    }
    public void selectCar() throws InterruptedException {
        driver.findElement(By.cssSelector(".insurance[data-type='Car']")).click();
        Thread.sleep(2000);
    }
    public void nextBtn(){
        driver.findElement(By.id("nextBtn")).click();
    }
}