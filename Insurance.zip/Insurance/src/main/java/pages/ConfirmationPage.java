package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
public class ConfirmationPage {
    WebDriver driver;
    public ConfirmationPage(WebDriver driver){
        this.driver = driver;
    }
    public void Confirm() throws InterruptedException{
        driver.findElement(By.id("nextBtn")).click();
        Thread.sleep(500);
    }
}