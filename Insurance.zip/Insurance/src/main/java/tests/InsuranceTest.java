package tests;
import base.BaseTest;
import org.testng.annotations.BeforeMethod;
import pages.*;
import org.testng.annotations.Test;
public class InsuranceTest extends BaseTest {
    @BeforeMethod
    public void start(){
        setup();
    }
    @Test
    public void testInsurance() throws InterruptedException {
        HomePage home=new HomePage(driver);
        InsurancePage insurance=new InsurancePage(driver);
        PlanPage plan=new PlanPage(driver);
        DetailsPage details=new DetailsPage(driver);
        ConfirmationPage confirmation=new ConfirmationPage(driver);
        home.selectQuote();
        home.scrollDown();
        insurance.selectCar();
        insurance.nextBtn();
        plan.selectPlan();
        plan.PlanNext();
        details.enterDetails();
        details.GoNext();
        confirmation.Confirm();
    }
}